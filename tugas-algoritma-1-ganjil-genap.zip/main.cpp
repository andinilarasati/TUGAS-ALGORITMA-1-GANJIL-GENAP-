/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    int bilangan;
    
   cout << endl;
   cout << "  =========================== " << endl;
   cout << "   BILANGAN GANJIL DAN GENAP  " << endl;
   cout << "  =========================== " << endl << endl;
   
   cout << "   MASUKAN BILANGAN : ";
   cin >> bilangan;
   cout << endl;
   
   if (bilangan%2==0){
       cout << bilangan << " ADALAH BILANGAN GENAP " << endl;
   }
     else {
         cout << bilangan << " ADALAH BILANGAN GANJIL " << endl;
     }
  
    return 0;
}

